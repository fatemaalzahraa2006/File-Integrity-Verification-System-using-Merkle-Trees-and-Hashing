//#pragma once
//#include <string>
//
//void processPath(const std::string& filePath);
//
#ifndef FILESELECTOR_H
#define FILESELECTOR_H

#include <string>

void processPath(const std::string& path, const std::string& hash);

#endif